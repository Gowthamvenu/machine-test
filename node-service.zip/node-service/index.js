const express = require('express');
const http = require('http');
const url = require('url');
const WebSocket = require('ws');
const fs=require('fs');
var LineByLineReader = require('line-by-line');

const app = express();
 
app.use(function (req, res) {
  res.send({ msg: "hello" });
});
 
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
 
wss.on('connection', function connection(ws, req) {
  const location = url.parse(req.url, true);
  // You might use location.query.access_token to authenticate or share sessions
  // or req.headers.cookie (see http://stackoverflow.com/a/16395220/151312)
 
    /* var readableStream=fs.createReadStream('/data/log.txt');
    rl.createInterface({
        input:readableStream,
        terminal:false
    });
    rl.on('line',function(line){
        console.log("line => "+line);
    }); */
    fs.watch('data/log.txt', (eventType, filename) => {
      console.log(`event type is: ${eventType}`);
      if (filename) {
        console.log(`filename provided: ${filename}`);
        let rl=new LineByLineReader('data/log.txt');
        rl.on('line',function(line){
            console.log("line => "+line);
            if(ws.readyState === WebSocket.OPEN){
                console.log("if");
                ws.send(line);
            }else{
                console.log("else");
            }
        });
      } else {
        console.log('filename not provided');
      }
    });
    let rl=new LineByLineReader('data/log.txt');
    rl.on('line',function(line){
        console.log("line => "+line);
        if(ws.readyState === WebSocket.OPEN){
            console.log("if");
            ws.send(line);
        }else{
            console.log("else");
        }
    });
  ws.on('message', function incoming(message) {
    console.log('received: %s', message);
  });
 /* setTimeout(function(){
    ws.send('after timeout');
    },3000) */
  //ws.send('something');
  ws.on('error', function(){
    ws.on('close',function(){
        console.log("closing");
    });
  });
});
 
server.listen(8080, function listening() {
  console.log('Listening on %d', server.address().port);
});
